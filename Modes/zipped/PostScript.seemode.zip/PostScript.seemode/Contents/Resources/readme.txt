PostScript mode for SubEthaEdit
-------------------------------

To install the mode, copy:

    PostScript.seemode

into
    
    ~/Library/Containers/SubEthaEdit/Data/Library/Application\ Support/de.codingmonkeys.SubEthaEdit.Mac/Modes/

To install the optional stylesheet, copy:

    PostScript.sss

into

    ~/Library/Containers/SubEthaEdit/Data/Library/Application\ Support/de.codingmonkeys.SubEthaEdit.Mac/Styles/

Nicolas Seriot
http://seriot.ch
February 2025
